package com.example.fllutter_barber_teste

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
